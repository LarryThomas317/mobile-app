
import React from 'react';
import { View, Text, TextInput, Button } from 'react-native';

export default function LoginScreen({ navigation }) {
  return (
    <View style={{ padding: 20 }}>
      <Text>Email</Text>
      <TextInput style={{ borderWidth: 1, marginBottom: 10 }} />
      <Text>Password</Text>
      <TextInput style={{ borderWidth: 1, marginBottom: 10 }} secureTextEntry />
      <Button title="Login" onPress={() => navigation.navigate('Dashboard')} />
      <Button title="Sign Up" onPress={() => navigation.navigate('Signup')} />
    </View>
  );
}
