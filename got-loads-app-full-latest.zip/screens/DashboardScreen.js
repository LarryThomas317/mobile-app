
import React from 'react';
import { View, Text } from 'react-native';

export default function DashboardScreen() {
  return (
    <View style={{ padding: 20 }}>
      <Text>Welcome to Got Loads? Dispatching L.L.C.</Text>
    </View>
  );
}
