
import React from 'react';
import { View, Text, TextInput, Button } from 'react-native';

export default function SignupScreen({ navigation }) {
  return (
    <View style={{ padding: 20 }}>
      <Text>Name</Text>
      <TextInput style={{ borderWidth: 1, marginBottom: 10 }} />
      <Text>Email</Text>
      <TextInput style={{ borderWidth: 1, marginBottom: 10 }} />
      <Text>Password</Text>
      <TextInput style={{ borderWidth: 1, marginBottom: 10 }} secureTextEntry />
      <Button title="Register" onPress={() => navigation.navigate('Login')} />
    </View>
  );
}
